# Docs

This directory mostly contains raw "documentation" that was written when
drafting the project. This is kept up-to-date.
